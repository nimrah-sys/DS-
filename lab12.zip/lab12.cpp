#include <iostream>
template<typename T>
class BST {
private:
	template<typename T>
	struct node {
		node *left, *right, *parent;
		T val;
		node<T>()
		{
			parent = left = right = head;
		}
	};
	
public:
	BST() {
		node *head;
		head = new node<T>;
		head->left = head->right = head->parent = head;
	}


	void insert(const T& val)
	{
		node<T> *temp;
		temp = new node<T>;
		temp->val = val;
		if (head->parent == head)
		{
			head->parent = temp;
			temp->parent = head;
			return;
		}
		node<T> *ptr = head->parent;
		while (true)
		{
			if (temp->val < ptr->val)
			{
				if (ptr->left != head)
					ptr = ptr->left;
				else {
					ptr->left = temp;
					temp->parent = ptr;
					return;
				}
			}
			else {
				if (ptr->right != head)
					ptr = ptr->right;
				else {
					ptr->right = temp;
					temp->parent = ptr;
					return;
				}
			}
		}


	}
	bool empty() const {
		return head->parent == head;
	}

};
int main()
{
	BST<int> bst;
	bst.insert(5);
	return 0;
}